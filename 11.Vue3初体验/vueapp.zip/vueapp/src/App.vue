<template>
  <CommentApp></CommentApp>
</template>

<script>
import CommentApp from "./components/CommentApp.vue";

export default {
  name: "App",
  components: {
    CommentApp,
  },
};
</script>

<style>
</style>
