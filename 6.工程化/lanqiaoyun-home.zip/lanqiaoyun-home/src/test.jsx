export default {
    name: "App",
    render() {
        return <div> Hello React!</div>;
    }
};