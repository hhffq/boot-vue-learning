// 导出 Tab 组件
export { default as NavTab } from "./tab";

// 导出 TabItem 组件
export { default as TabItem } from "./tab-item";